export enum Status {
  DRAFTED = "DRAFTED",
  PUBLISHED = "PUBLISHED",
  LOCKED = "LOCKED",
}

export enum GroupPermission {
  ROLES = "ROLES",
}
