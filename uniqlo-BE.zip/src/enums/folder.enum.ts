export enum Folder {
  USERS = "users",
  HOTELS = "hotels",
  ROOMS = "rooms",
  TOURS = "tours",
}
