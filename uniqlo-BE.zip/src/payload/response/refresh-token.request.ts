export class RefreshTokenResponse {
  access_token: string;
}
