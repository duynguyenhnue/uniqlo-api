export class WarehouseResponse {
    id: string; 
    name: string;
    code: string;
    address: string;
    staff: string[];
    isActive: boolean;

  }